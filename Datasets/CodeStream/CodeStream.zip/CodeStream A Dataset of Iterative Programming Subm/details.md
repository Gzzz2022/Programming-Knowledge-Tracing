# Dataset Metadata Documentation

## Overview

This dataset captures user interactions with programming problems in an online coding environment. It consists of submission-level records linked with problem-level metadata, enabling analysis of user behavior, learning patterns, and code evaluation outcomes.

The dataset is organized into two primary tables:

1. **Submission Data** – records of user attempts and evaluation results
2. **Problem Data** – descriptions and associated evaluation test cases

---

## 1. Submission Data

This table contains detailed records of individual code submissions made by users.

### Variables Description

| Variable Name            | Description                                                                 |
| ------------------------ | --------------------------------------------------------------------------- |
| `submission_id`          | Unique identifier for each submission                                       |
| `user_id`                | Unique identifier for the user                                              |
| `problem_id`             | Identifier linking to the corresponding problem                             |
| `attempt_number`         | Sequential attempt index for a given user–problem pair                      |
| `programming_language`   | Programming language used in the submission                                 |
| `source_code`            | Raw source code submitted by the user                                       |
| `final_verdict`          | Final evaluation result (e.g., Accepted, Wrong Answer, Time Limit Exceeded) |
| `verdict_sequence_trace` | Ordered sequence of intermediate evaluation outcomes                        |

### Notes

* Each row represents a **single submission event**.
* Multiple submissions may exist for the same user–problem pair.
* The `verdict_sequence_trace` variable reflects the progression of evaluation across test cases.

---

## 2. Problem Data (problems)

This table provides metadata describing each programming problem.

### Variables Description

| Variable Name           | Description                                        |
| ----------------------- | -------------------------------------------------- |
| `problem_id`            | Unique identifier for each problem                 |
| `problem_description`   | Full textual description of the problem statement  |
| `evaluation_test_cases` | Set of input-output test cases used for evaluation |

### Notes

* This table serves as a **reference table** linked via `problem_id`.
* The `evaluation_test_cases` variable may contain structured or serialized representations of test inputs and expected outputs.

---

## Data Relationships

* The dataset follows a **relational structure**:

  * `problem_id` acts as a **foreign key** in the submission data.
  * Each submission is associated with exactly one problem.
  * Each problem may have multiple submissions from different users.

---
